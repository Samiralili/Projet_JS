var note1, note2, note3, note4, note5, note6, note7, note8, note9, note10,t,result;
alert("Entrez vos 10 notes une par une et de 0 à 20");
note1 = prompt('Entrez Note 1 :');
note2 = prompt('Entrez Note 2 :');
note3 = prompt('Entrez Note 3 :');
note4 = prompt('Entrez Note 4 :');
note5 = prompt('Entrez Note 5 :');
note6 = prompt('Entrez Note 6 :');
note7 = prompt('Entrez Note 7 :');
note8 = prompt('Entrez Note 8 :');
note9 = prompt('Entrez Note 9 :');
note10 = prompt('Entrez Note 10 :');
t = parseInt(note1) + parseInt(note2) + parseInt(note3) + parseInt(note4) + parseInt(note5) + parseInt(note6) + parseInt(note7) + parseInt(note8) + parseInt(note9) + parseInt(note10);
result = t / 10;
alert ("Votre moyenne est "+ result)

var result="Quelle est la couleur du cheval blanc d'Henri 4?";
    result2= "Combien y a-t-il de 7 nains?";
    alert(result);
	alert(result2);
var first, second;
first= prompt("entrez votre identifiant");
second= prompt("entrez votre mot de passe");
    if ((first.length > 4 && first==='@'),(first==='lea@gmail.com' && second==='12345'))
	{
	alert("correct");
}
	   else{
         alert("C'est faut");
       }

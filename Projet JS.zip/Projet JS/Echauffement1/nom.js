var prenom = prompt("Comment tu t'appelles?");
    prenom!=null;
    if (prenom.length >= 1 && prenom.length <= 10)
{
       alert("Bonjour "  +  prenom  +  "!");
}
    else {
       alert("Oups!!!! Ton Prénom doit centenir entre 1 et 10 caractères");
}
var nb = Math.floor(Math.random() * 8); 
var cps = 0; 
var saisie=-1;
console.log(prompt("Saurez-vous trouver le nombre mystère entre 0 et 9 ?!"));
var cps = 0; 
var saisie=-1;
while ((saisie !== nb) && (cps < 3)) {
    cps++;
	saisie = Number(prompt("Entrez votre proposition " + cps + " :"));
    if (saisie < nb) {
        console.log (prompt("plus"));
    } else if (saisie > nb) {
        console.log(prompt("moins"));
    }
}
if (saisie === nb) {
    console.log(prompt("Bravo ! La solution était " + nb));
    console.log(prompt("Vous avez trouvé en " + cps + " essai(s)"));
} else {
    console.log(prompt("Perdu. La solution était " + nb));
}
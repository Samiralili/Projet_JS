var op = Math.floor(Math.random('-','*','+') * 0); 
var chiffre = Math.floor(Math.random() * 1); 
var cps = 0; 
cps++;
var x,y,a,b,c;
a=x+y;
b=x*y;
c=x-y;
var result;
var msg=prompt ("Combien fait ", x+y||x*y||x-y);

if (result == a||b||c)
  {
  alert("true");
  }
else
  {
    
    alert("false");
}
  